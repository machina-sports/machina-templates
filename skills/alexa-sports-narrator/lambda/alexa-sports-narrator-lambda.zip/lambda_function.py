"""
Alexa Sports Narrator - Lambda Handler
Integrates with Machina workflows to provide sports updates via Alexa
"""

import os
import json
import logging
from typing import Dict, Any
from machina import Machina

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize Machina client
machina_client = Machina(
    api_key=os.environ.get('MACHINA_API_KEY'),
    base_url=os.environ.get('MACHINA_BASE_URL', 'https://api.machina.sports')
)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main Lambda handler for Alexa skill requests

    Args:
        event: Alexa request event
        context: Lambda context

    Returns:
        Alexa response format
    """
    logger.info(f"Received event: {json.dumps(event)}")

    try:
        request_type = event['request']['type']

        if request_type == 'LaunchRequest':
            return handle_launch_request(event)
        elif request_type == 'IntentRequest':
            return handle_intent_request(event)
        elif request_type == 'SessionEndedRequest':
            return handle_session_ended_request(event)
        else:
            logger.warning(f"Unknown request type: {request_type}")
            return build_response("Sorry, I didn't understand that request.")

    except Exception as e:
        logger.error(f"Error processing request: {str(e)}", exc_info=True)
        return build_response("Sorry, I encountered an error. Please try again.")


def handle_launch_request(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle LaunchRequest - when user opens the skill"""
    language = event.get('request', {}).get('locale', 'en-US')

    if language.startswith('pt'):
        speech_text = "Bem-vindo ao Narrador Esportivo! Você pode me perguntar sobre resultados da NFL, NBA, futebol e muito mais. O que você gostaria de saber?"
        card_title = "Narrador Esportivo"
    else:
        speech_text = "Welcome to Sports Narrator! You can ask me about NFL scores, NBA results, soccer matches, and more. What would you like to know?"
        card_title = "Sports Narrator"

    return build_response(
        speech_text=speech_text,
        card_title=card_title,
        card_text=speech_text,
        should_end_session=False
    )


def handle_intent_request(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle IntentRequest - when user invokes a specific intent"""
    intent = event['request']['intent']
    intent_name = intent['name']
    session = event.get('session', {})
    user_id = session.get('user', {}).get('userId', 'unknown')
    language = event.get('request', {}).get('locale', 'en-US')

    logger.info(f"Processing intent: {intent_name}")

    # Route to appropriate handler
    intent_handlers = {
        'GetNFLScoresIntent': handle_sports_query,
        'GetNBAScoresIntent': handle_sports_query,
        'GetSoccerScoresIntent': handle_sports_query,
        'GetTeamStatsIntent': handle_sports_query,
        'GetPlayerStatsIntent': handle_sports_query,
        'GetPersonalizedUpdateIntent': handle_personalized_update,
        'SetFavoriteTeamIntent': handle_set_favorite_team,
        'AMAZON.HelpIntent': handle_help,
        'AMAZON.CancelIntent': handle_cancel,
        'AMAZON.StopIntent': handle_stop,
    }

    handler = intent_handlers.get(intent_name)
    if handler:
        return handler(intent, user_id, language)
    else:
        logger.warning(f"Unhandled intent: {intent_name}")
        return build_response("Sorry, I don't know how to help with that yet.")


def handle_sports_query(intent: Dict[str, Any], user_id: str, language: str) -> Dict[str, Any]:
    """Handle sports query intents (scores, stats, etc.)"""
    intent_name = intent['name']
    slots = intent.get('slots', {})

    # Extract slot values
    team = slots.get('team', {}).get('value')
    player = slots.get('player', {}).get('value')
    date = slots.get('date', {}).get('value')

    # Determine sport from intent name
    sport_mapping = {
        'GetNFLScoresIntent': 'nfl',
        'GetNBAScoresIntent': 'nba',
        'GetSoccerScoresIntent': 'soccer',
    }
    sport = sport_mapping.get(intent_name, 'nfl')

    # If team slot exists but no sport in intent, try to infer
    if 'TeamStatsIntent' in intent_name and team:
        sport = slots.get('sport', {}).get('value', 'nfl')

    # Execute Machina workflow
    try:
        workflow_result = machina_client.execute_workflow(
            workflow_name='alexa-sports-query',
            inputs={
                'intent_name': intent_name,
                'sport': sport,
                'team': team,
                'player': player,
                'date': date,
                'language': language,
                'user_id': user_id
            }
        )

        response_text = workflow_result.get('response_text', 'No data available.')
        card_title = workflow_result.get('card_title', 'Sports Update')
        card_text = workflow_result.get('card_text', response_text[:200])
        should_end_session = workflow_result.get('should_end_session', True)

        return build_response(
            speech_text=response_text,
            card_title=card_title,
            card_text=card_text,
            should_end_session=should_end_session
        )

    except Exception as e:
        logger.error(f"Workflow execution error: {str(e)}", exc_info=True)
        error_msg = "Sorry, I couldn't get the sports data right now. Please try again later."
        if language.startswith('pt'):
            error_msg = "Desculpe, não consegui obter os dados esportivos agora. Tente novamente mais tarde."
        return build_response(error_msg)


def handle_personalized_update(intent: Dict[str, Any], user_id: str, language: str) -> Dict[str, Any]:
    """Handle personalized sports update request"""
    try:
        workflow_result = machina_client.execute_workflow(
            workflow_name='alexa-personalized-update',
            inputs={
                'user_id': user_id,
                'language': language
            }
        )

        response_text = workflow_result.get('response_text', 'No favorites set.')

        return build_response(
            speech_text=response_text,
            card_title='Your Sports Update',
            card_text=response_text[:200],
            should_end_session=True
        )

    except Exception as e:
        logger.error(f"Personalized update error: {str(e)}", exc_info=True)
        return build_response("Sorry, I couldn't get your personalized update.")


def handle_set_favorite_team(intent: Dict[str, Any], user_id: str, language: str) -> Dict[str, Any]:
    """Handle setting favorite team"""
    slots = intent.get('slots', {})
    team_name = slots.get('team', {}).get('value')
    sport = slots.get('sport', {}).get('value', 'nfl')

    if not team_name:
        msg = "I didn't catch the team name. Please say it again."
        if language.startswith('pt'):
            msg = "Não entendi o nome do time. Por favor, diga novamente."
        return build_response(msg, should_end_session=False)

    try:
        workflow_result = machina_client.execute_workflow(
            workflow_name='alexa-save-favorite-team',
            inputs={
                'user_id': user_id,
                'team_name': team_name,
                'sport': sport,
                'language': language
            }
        )

        response_text = workflow_result.get('response_text', 'Team saved!')

        return build_response(
            speech_text=response_text,
            card_title='Favorite Team Added',
            card_text=f"{team_name} added to favorites",
            should_end_session=False
        )

    except Exception as e:
        logger.error(f"Set favorite team error: {str(e)}", exc_info=True)
        return build_response("Sorry, I couldn't save your favorite team.")


def handle_help(intent: Dict[str, Any], user_id: str, language: str) -> Dict[str, Any]:
    """Handle AMAZON.HelpIntent"""
    if language.startswith('pt'):
        help_text = """
        Você pode me perguntar:
        - Quais foram os resultados da NFL hoje?
        - Como está o Lakers nesta temporada?
        - Me dê minha atualização esportiva personalizada.
        - Meu time favorito é o Kansas City Chiefs.
        O que você gostaria de saber?
        """
    else:
        help_text = """
        You can ask me things like:
        - What were the NFL scores today?
        - How are the Lakers doing this season?
        - Give me my personalized sports update.
        - My favorite team is the Kansas City Chiefs.
        What would you like to know?
        """

    return build_response(
        speech_text=help_text,
        card_title='Help',
        card_text=help_text,
        should_end_session=False
    )


def handle_cancel(intent: Dict[str, Any], user_id: str, language: str) -> Dict[str, Any]:
    """Handle AMAZON.CancelIntent"""
    msg = "Goodbye!" if not language.startswith('pt') else "Até logo!"
    return build_response(msg, should_end_session=True)


def handle_stop(intent: Dict[str, Any], user_id: str, language: str) -> Dict[str, Any]:
    """Handle AMAZON.StopIntent"""
    msg = "Goodbye!" if not language.startswith('pt') else "Até logo!"
    return build_response(msg, should_end_session=True)


def handle_session_ended_request(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle SessionEndedRequest"""
    reason = event['request'].get('reason', 'USER_INITIATED')
    logger.info(f"Session ended. Reason: {reason}")
    return {}


def build_response(
    speech_text: str,
    card_title: str = None,
    card_text: str = None,
    should_end_session: bool = True,
    reprompt_text: str = None
) -> Dict[str, Any]:
    """
    Build Alexa response in proper format

    Args:
        speech_text: Text for Alexa to speak
        card_title: Title for Alexa app card
        card_text: Text for Alexa app card
        should_end_session: Whether to end the session
        reprompt_text: Text for reprompt if user doesn't respond

    Returns:
        Alexa response dictionary
    """
    response = {
        'version': '1.0',
        'response': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': speech_text
            },
            'shouldEndSession': should_end_session
        }
    }

    # Add card if title/text provided
    if card_title or card_text:
        response['response']['card'] = {
            'type': 'Simple',
            'title': card_title or 'Sports Narrator',
            'content': card_text or speech_text
        }

    # Add reprompt if provided
    if reprompt_text:
        response['response']['reprompt'] = {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        }

    return response
